

function mostrarMenuMob(){
    document.querySelector('#navbarCollapse').style.display='flex';
}
function mostrarMenuMobII(){
    document.querySelector('#navbarCollapseII').style.display='flex';
}

function fecharMenuMob(){
    document.querySelector('#navbarCollapse').style.display='none';
}
function remMenuMobII(){
    document.querySelector('#navbarCollapseII').style.display='none';
}

const moLo = document.querySelector('.nav-login');

function mostrarLogin(){    
    moLo.classList.add("active");
    document.querySelector('#navbarCollapse').style.display='none';
};

const popupLogin = document.querySelector('.nav-login');
const popupCadastro = document.querySelector('.cadastro');

function mostrarPopup(){
    popupLogin.classList.add("active");
    ocultarCadastro();
};
function mostrarCadastro(){
    popupCadastro.classList.add("active");
    ocultarPopup();
};

function ocultarPopup(){
    popupLogin.classList.remove("active");
};
function ocultarCadastro(){
    popupCadastro.classList.remove("active");
};
